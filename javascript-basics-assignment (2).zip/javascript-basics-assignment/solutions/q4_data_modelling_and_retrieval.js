// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast


// Write your code here
const fruits=[
    {   name:"apple",
        color:"red",
        priceperkg:100
    },
    {
        name:"sapota",
        color:"brown",
        priceperkg:200
    },
    {
        name:"mango",
        color:"orange",
        priceperkg:300
    },
    {
        name:"guava",
        color:"green",
        priceperkg:400
    },
    {
        name:"lemon",
        color:"yellow",
        priceperkg:500
    }
];
let givename=prompt("Enter name");
const res=fruits.find(i => i.name === givename);
console.log(res);
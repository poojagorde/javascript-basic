// Write a program to display one result card of 100 students
// with their name and percentage
// Out of 100 students, 50 has subjects - Grammer and Accounts
// and other 50 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 100 students having different set of subjects.
//        You can assume their scores on their respective subjects.


// Write your code here
var arr=[
    {name:'john',subject:['Grammar','Accounts'],scores:[20,40]},
    {name:'jones',subject:['Grammar','Accounts'],scores:[30,40]},
    {name:'krish',subject:['Grammar','Accounts'],scores:[40,40]},
    {name:'stanely',subject:['Grammar','Accounts'],scores:[50,40]},
    {name:'ravi',subject:['Grammar','Accounts'],scores:[20,70]},


    {name:'alex',subject:['Grammar','Physics'],scores:[20,40]},
    {name:'rajesh',subject:['Grammar','Physics'],scores:[20,40]},
    {name:'pritvish',subject:['Grammar','Physics'],scores:[20,40]},
    {name:'dileep',subject:['Grammar','Physics'],scores:[20,40]},
    {name:'shyam',subject:['Grammar','Physics'],scores:[20,40]},
]


var temp = arr.map((items,index)=>{         
let totalscore =  items.scores.reduce((a, b) => a + b, 0);  
let percentage = (totalscore/200)*100;
items.percentage =percentage;
return items;
})   

temp.map(namevalues=>{
console.log("name:"+namevalues.name + "   " + "Percentage:"+namevalues.percentage)
})

/* Write a program to build a `Pyramid of stars` of given height */

const buildPyramid = (n) => {
   let s1="";

   for(let i=1;i<=n;i++)
   {
        for(let j=1;j<=n-i+1;j++)
        {
	        s1+=" ";
        }
	    for(let k=1;k<=i;k++)
	    {
	        s1+="* ";
	   }
       s1+=" \n";
    }
    return s1;
	// Write your code here
};

/* For example,
INPUT - buildPyramid(6)
OUTPUT -
     *
    * *
   * * *
  * * * *
 * * * * *
* * * * * *

*/

module.exports = buildPyramid;
